const { MongoClient,ServerApiVersion } = require('mongodb');

// Connection URL and Database Name
const uri = "mongodb+srv://22456506:2245650622456506@mydb.li7ouls.mongodb.net/?retryWrites=true&w=majority&appName=myDB";
const dbName = 'mobileStore';
// Create a new MongoClient
const client = new MongoClient(uri, {
    serverApi: {
        version: ServerApiVersion.v1,
        strict: true,
        deprecationErrors: true,
    }
});
async function connect() {
    try {
        await client.connect();
        await client.db("admin").command({ ping: 1 });
        console.log("Connected correctly to server");
        const db = client.db(dbName);
        return db;
    } catch (err) {
        console.error(err);
        throw new Error('Failed to connect to MongoDB');
    }
}

// Customer CRUD
async function insertCustomer(customer) {
    const db = await connect();
    return db.collection('customers').insertOne(customer);
}
async function findCustomer(query) {
    const db = await connect();
    const customer = await db.collection('customers').findOne(query);
    console.log(customer);
    return customer;
}
async function updateCustomer(query, update) {
    const db = await connect();
    return db.collection('customers').updateOne(query, { $set: update });
}
async function deleteCustomer(query) {
    const db = await connect();
    return db.collection('customers').deleteOne(query);
}

// Item CRUD
async function insertItem(item) {
    const db = await connect();
    return db.collection('items').insertOne(item);
}
async function findItem(query) {
    const db = await connect();
    const item = await db.collection('items').findOne(query);
    console.log(item);
    return item;
}
async function updateItem(query, update) {
    const db = await connect();
    return db.collection('items').updateOne(query, { $set: update });
}
async function deleteItem(query) {
    const db = await connect();
    return db.collection('items').deleteOne(query);
}

// Orders CRUD
async function insertOrder(order) {
    const db = await connect();
    return db.collection('orders').insertOne(order);
}
async function findOrder(query) {
    const db = await connect();
    const order = await db.collection('orders').findOne(query);
    console.log(order);
    return order;
}
async function updateOrder(query, update) {
    const db = await connect();
    return db.collection('orders').updateOne(query, { $set: update });
}
async function deleteOrder(query) {
    const db = await connect();
    return db.collection('orders').deleteOne(query);
}

//Examples search a customer called Bob
async function runSearch() {
    await findCustomer({ firstName: "Bob" });
}
runSearch().catch(console.error);

//Assignment-05 requirements: <!--Google Chrome version 122.0.6261.69（Official Build） (arm64)-->