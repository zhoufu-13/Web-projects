const { MongoClient,ServerApiVersion } = require('mongodb');
const uri = "mongodb+srv://22456506:2245650622456506@mydb.li7ouls.mongodb.net/?retryWrites=true&w=majority&appName=myDB";
const dbName = 'mobileStore';
// Create a new MongoClient

// Create a MongoClient with a MongoClientOptions object to set the Stable API version
const client = new MongoClient(uri, {
    serverApi: {
        version: ServerApiVersion.v1,
        strict: true,
        deprecationErrors: true,
    }
});

async function connect() {
    try {
        await client.connect();
        await client.db("admin").command({ ping: 1 });
        console.log("Connected correctly to server");
        const db = client.db(dbName);
        return db;
    } catch (err) {
        console.error(err);
        throw new Error('Failed to connect to MongoDB');
    }
}

async function insertData(collection, data) {
    const db = await connect();
    return db.collection(collection).insertMany(data);
}

async function insert_examples() {
    try {
        // Insert sample customers
        await insertData('customers', [
            { firstName: 'Alice', surname: 'Johnson', mobile: '1111111111', email: 'alice@example.com' },
            { firstName: 'Bob', surname: 'Smith', mobile: '2222222222', email: 'bob@example.com' },
            { firstName: 'Carol', surname: 'Martinez', mobile: '3333333333', email: 'carol@example.com' },
            { firstName: 'David', surname: 'Lee', mobile: '4444444444', email: 'david@example.com' },
            { firstName: 'Eve', surname: 'Jordan', mobile: '5555555555', email: 'eve@example.com' },
            { firstName: 'Frank', surname: 'Clark', mobile: '6666666666', email: 'frank@example.com' },
            { firstName: 'Grace', surname: 'Lopez', mobile: '7777777777', email: 'grace@example.com' },
            { firstName: 'Henry', surname: 'White', mobile: '8888888888', email: 'henry@example.com' },
            { firstName: 'Isabel', surname: 'Taylor', mobile: '9999999999', email: 'isabel@example.com' },
            { firstName: 'Jack', surname: 'Davis', mobile: '1010101010', email: 'jack@example.com' }
        ]);

        console.log("Customers inserted.");

        // Insert sample items
        await insertData('items', [
            { manufacturer: 'Apple', model: 'iPhone 12', price: 799 },
            { manufacturer: 'Apple', model: 'iPhone 13', price: 899 },
            { manufacturer: 'Samsung', model: 'Galaxy S20', price: 750 },
            { manufacturer: 'Samsung', model: 'Galaxy S21', price: 850 },
            { manufacturer: 'Google', model: 'Pixel 5', price: 699 },
            { manufacturer: 'Google', model: 'Pixel 6', price: 799 },
            { manufacturer: 'OnePlus', model: 'OnePlus 9', price: 729 },
            { manufacturer: 'OnePlus', model: 'OnePlus 8T', price: 599 },
            { manufacturer: 'Sony', model: 'Xperia 5 II', price: 950 },
            { manufacturer: 'Sony', model: 'Xperia 1 II', price: 1200 }
        ]);

        console.log("Items inserted.");

        // Insert sample orders (example customerId and itemId would need to be replaced with actual MongoDB ObjectIds)
        await insertData('orders', [
            { customerId: 'someObjectId1', items: [{ itemName: 'iPhone 12', quantity: 2 }], orderDate: new Date() },
            { customerId: 'someObjectId2', items: [{ itemName: 'iPhone 13', quantity: 1 }], orderDate: new Date() },
            { customerId: 'someObjectId3', items: [{ itemName: 'Galaxy S20', quantity: 1 }, { itemName: 'Galaxy S21', quantity: 1 }], orderDate: new Date() },
            { customerId: 'someObjectId4', items: [{ itemName: 'Pixel 5', quantity: 3 }], orderDate: new Date() },
            { customerId: 'someObjectId5', items: [{ itemName: 'Pixel 6', quantity: 1 }, { itemName: 'OnePlus 9', quantity: 1 }], orderDate: new Date() },
            { customerId: 'someObjectId6', items: [{ itemName: 'OnePlus 8T', quantity: 2 }], orderDate: new Date() },
            { customerId: 'someObjectId7', items: [{ itemName: 'Xperia 5 II', quantity: 2 }], orderDate: new Date() },
            { customerId: 'someObjectId8', items: [{ itemName: 'Xperia 1 II', quantity: 1 }], orderDate: new Date() },
            { customerId: 'someObjectId9', items: [{ itemName: 'iPhone 12', quantity: 1 }, { itemName: 'iPhone 13', quantity: 1 }], orderDate: new Date() },
            { customerId: 'someObjectId10', items: [{ itemName: 'Galaxy S21', quantity: 1 }, { itemName: 'OnePlus 9', quantity: 1 }], orderDate: new Date() }
        ]);


        console.log("Orders inserted.");
    } catch (err) {
        console.error("Error inserting sample data:", err);
    } finally {
        client.close();
    }
}

insert_examples();
