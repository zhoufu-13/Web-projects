$(document).ready(function() {
    $('#createUserForm').on('submit', function(e) {
        e.preventDefault();
        const userData = {
            title: $('#title').val(),
            firstName: $('#firstName').val(),
            surname: $('#surname').val(),
            mobile: $('#mobile').val(),
            email: $('#email').val(),
            // Include other fields as necessary
        };
        // Home address information
        const homeAddress = {
            address1: $('#homeAddress1').val(),
            address2: $('#homeAddress2').val(),
            town: $('#homeTown').val(),
            county: $('#homeCounty').val(),
            eircode: $('#homeEircode').val(),
        };

        // Shipping address information
        const shippingAddress = {
            address1: $('#shippingAddress1').val(),
            address2: $('#shippingAddress2').val(),
            town: $('#shippingTown').val(),
            county: $('#shippingCounty').val(),
            eircode: $('#shippingEircode').val(),
        };

        const data = { ...userData, homeAddress, shippingAddress };

        // AJAX call to backend for creating a user
        $.ajax({
            type: 'POST',
            url: '/api/users', // Adjust based on your API endpoint
            contentType: 'application/json',
            data: JSON.stringify(data),
            success: function(response) {
                alert('User created successfully');
                // Clear form or handle response
            },
            error: function(error) {
                console.error('Error creating user:', error);
            }
        });
    });

    $('#searchUserForm').on('submit', function(e) {
        e.preventDefault();
        const query = $('#searchQuery').val();
        // AJAX call to backend for searching users
        $.ajax({
            type: 'GET',
            url: `/api/users/search?query=${encodeURIComponent(query)}`, // Adjust based on your API endpoint
            success: function(response) {
                // Process and display search results
                $('#searchResults').html(JSON.stringify(response)); // Update to format the results properly
            },
            error: function(error) {
                console.error('Error searching for users:', error);
            }
        });
    });
});
