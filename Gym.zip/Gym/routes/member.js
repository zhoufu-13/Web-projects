const express = require('express');
const router = express.Router();
const Member = require('../models/Member');

//Create
router.post('/', async(req, res) => {
    try{
        const newMember = new Member(req.body);
        const saveMember = await newMember.save();
        res.status(201).send(saveMember);
    } catch (err) {
        res.status(400).send(err);
    }
});

//get member by ID
router.get('/:id', async(req, res) => {
    try{
        const member = await Member.findById(req.params.id);
        if(!member){
            return res.status(404).send("Member not found");
        }
        res.status(200).send(member);
    } catch (err) {
        res.status(500).send(err);
    }
});

// GET all members
router.get('/', async (req, res) => {
    try {
        const members = await Member.find();
        res.status(200).send(members);
    } catch (err) {
        res.status(500).send(err);
    }
});

// Update
router.put('/:id', async (req, res) => {
    try{
        const updateMember = await Member.findByIdUpdate(req.params.id, req.body, {new: true});
        res.status(200).send(updateMember);
    } catch (err) {
        res.status(400).send(err);
    }
});

//Delete
router.delete('/:id', async (req, res) => {
    try{
        const deleteMember = await Member.findByIdAndDelete(req.params.id);
        if(!deleteMember) {
            return res.status(404).send("Member not found");
        }
        res.status(200).send(deleteMember);
    } catch (err) {
        res.status(500).send(err);
    }
});
module.exports = router;
