const express = require('express');
const router = express.Router();
const Class = require('../models/Class');

// POST to create a new class
router.post('/', async (req, res) => {
    try {
        const newClass = new Class(req.body);
        const savedClass = await newClass.save();
        res.status(201).send(savedClass);
    } catch (err) {
        res.status(400).send(err);
    }
});

// GET all classes
router.get('/', async (req, res) => {
    try {
        const classes = await Class.find();
        res.status(200).send(classes);
    } catch (err) {
        res.status(500).send(err);
    }
});

// GET by ID
router.get('/:id', async (req, res) => {
    try {
        const gymClass = await Class.findById(req.params.id);
        if (!gymClass) {
            return res.status(404).send("Class not found");
        }
        res.status(200).send(gymClass);
    } catch (err) {
        res.status(500).send(err);
    }
});

// Update
router.put('/:id', async (req, res) => {
    try {
        const updatedClass = await Class.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.status(200).send(updatedClass);
    } catch (err) {
        res.status(400).send(err);
    }
});

// DELETE
router.delete('/:id', async (req, res) => {
    try {
        const deletedClass = await Class.findByIdAndDelete(req.params.id);
        if (!deletedClass) {
            return res.status(404).send("Class not found");
        }
        res.status(200).send(deletedClass);
    } catch (err) {
        res.status(500).send(err);
    }
});

module.exports = router;