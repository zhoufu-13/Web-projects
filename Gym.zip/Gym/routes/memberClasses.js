const express = require('express');
const router = express.Router();
const MemberClass = require('../models/MemberClass');

//Create
router.post('/', async(req, res) => {
    try{
        const newMemClass = new MemberClass(req, res);
        const saveMenClass = await newMemClass.save();
        res.status(201).send(saveMemClass);
    } catch(err) {
        res.status(500).send(err);
    }
});

//Get by id
router.get('/:id', async(req, res) => {
    try{
        const memberClass = await MemberClass.findById(req.params.id).populate('userId').populate('classId');
        if(!memberClass){
            return res.status(404).send("Member-class not find");
        }
        res.status(200).send(memberClass);
    } catch (err){
        res.status(500).send(err);
    }
});

// GET all member-classes
router.get('/', async (req, res) => {
    try {
        const memberClasses = await MemberClass.find().populate('userId').populate('classId');
        res.status(200).send(memberClasses);
    } catch (err) {
        res.status(500).send(err);
    }
});

//Update
router.put('/:id', async(req, res) => {
    try{
        const memberClass = await MemberClass.findByIdAndUpdate(req.params.id, {
            userId: req.body.userId,
            classId: req.body.classId
        }, {new: true}).populate('userId').populate('classId');

        if(!memberClass){
            return res.status(404).send("Member class not find");
        }
        res.status(200).send(memberClass);
    } catch(err){
        res.status(400).send(err);
    }
});

//Delete
router.delete('/:id', async(req, res) => {
    try{
        const deleteMemClass = await MemberClass.findByIdAndDelete(req.params.id);
        if(!deleteMemClass){
            return res.status(404).send("Member class not find");
        }
        res.status(200).send(deleteMemClass);
    } catch(err) {
        res.status(500).send(err);
    }
});
module.exports = router;