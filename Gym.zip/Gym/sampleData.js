const mongoose = require('mongoose');
const Member = require('./models/member');
const Class = require('./models/Class');
const MemberClass = require('./models/MemberClass');

mongoose.connect('mongodb+srv://22456506:2245650622456506@mydb.li7ouls.mongodb.net/Gym');

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function () {
    console.log("Connected successfully");
    createData();
});

async function createData() {
    try {
        await db.dropCollection('members');
        await db.dropCollection('classes');
        await db.dropCollection('memberclasses');

        await Member.insertMany([
            { title: "Mr", firstName: "John", lastName: "Doe", email: "john.doe@example.com", premiumMembership: true },
            { title: "Ms", firstName: "Jane", lastName: "Smith", email: "jane.smith@example.com", premiumMembership: false },
            { title: "Dr", firstName: "Alice", lastName: "Brown", email: "alice.brown@example.com", premiumMembership: true },
            { title: "Mrs", firstName: "Mary", lastName: "Jones", email: "mary.jones@example.com", premiumMembership: false },
            { title: "Mr", firstName: "Robert", lastName: "Wilson", email: "robert.wilson@example.com", premiumMembership: true },
            { title: "Ms", firstName: "Patricia", lastName: "Miller", email: "patricia.miller@example.com", premiumMembership: false },
            { title: "Dr", firstName: "Jennifer", lastName: "Davis", email: "jennifer.davis@example.com", premiumMembership: true },
            { title: "Mr", firstName: "Charles", lastName: "Garcia", email: "charles.garcia@example.com", premiumMembership: true },
            { title: "Mrs", firstName: "Linda", lastName: "Martinez", email: "linda.martinez@example.com", premiumMembership: false },
            { title: "Ms", firstName: "Elizabeth", lastName: "Hernandez", email: "elizabeth.hernandez@example.com", premiumMembership: true }
        ]);

        await Class.insertMany([
            { className: "Yoga", classDay: "Monday", sessionLength: 2, price: 20, currentNumberMembers: 10 },
            { className: "Pilates", classDay: "Tuesday", sessionLength: 1, price: 15, currentNumberMembers: 8 },
            { className: "Zumba", classDay: "Wednesday", sessionLength: 1, price: 25, currentNumberMembers: 12 },
            { className: "Spinning", classDay: "Thursday", sessionLength: 2, price: 30, currentNumberMembers: 9 },
            { className: "CrossFit", classDay: "Friday", sessionLength: 1, price: 35, currentNumberMembers: 15 },
            { className: "Cardio", classDay: "Saturday", sessionLength: 1.5, price: 18, currentNumberMembers: 14 },
            { className: "Strength Training", classDay: "Sunday", sessionLength: 1.5, price: 22, currentNumberMembers: 16 },
            { className: "Boxing", classDay: "Monday", sessionLength: 1, price: 20, currentNumberMembers: 7 },
            { className: "MMA", classDay: "Tuesday", sessionLength: 2, price: 40, currentNumberMembers: 6 },
            { className: "Aerobics", classDay: "Wednesday", sessionLength: 2, price: 25, currentNumberMembers: 13 }
        ]);

        const members = await Member.find();
        const classes = await Class.find();

        await MemberClass.insertMany([
            { userId: members[0]._id, classId: classes[0]._id },
            { userId: members[1]._id, classId: classes[1]._id },
            { userId: members[2]._id, classId: classes[2]._id },
            { userId: members[3]._id, classId: classes[3]._id },
            { userId: members[4]._id, classId: classes[4]._id },
            { userId: members[5]._id, classId: classes[5]._id },
            { userId: members[6]._id, classId: classes[6]._id },
            { userId: members[7]._id, classId: classes[7]._id },
            { userId: members[8]._id, classId: classes[8]._id },
            { userId: members[9]._id, classId: classes[9]._id }
        ]);

        console.log('Data Created Successfully!');
        process.exit();
    } catch (error) {
        console.error('Error creating data:', error);
        process.exit(1);
    }
}
