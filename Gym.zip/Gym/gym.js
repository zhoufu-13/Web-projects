//Assignment 06 - Requirements
//https://mongoosejs.com/docs/
//https://blog.appsignal.com/2023/08/09/how-to-use-mongodb-and-mongoose-for-nodejs.html
//Test on Google Chrome version 122.0.6261.69（Official Build） (arm64)

const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express();
const port = process.env.PORT || 3001;

// Body parser middleware
app.use(bodyParser.json());

//MongoDB connection
mongoose.connect('mongodb+srv://22456506:2245650622456506@mydb.li7ouls.mongodb.net/Gym');

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));

// Import routes
const memberRoutes = require('./routes/member');
const classesRoutes = require('./routes/classes');
const memberClassesRoutes = require('./routes/memberClasses');

// Use Routes
app.use('/api/member', memberRoutes);
app.use('/api/classes', classesRoutes);
app.use('/api/member-classes', memberClassesRoutes);

app.listen(port, '0.0.0.0', () => {
    console.log(`Server listening on port ${port}`);
});