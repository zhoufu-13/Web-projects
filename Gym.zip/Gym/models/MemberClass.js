const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const MemberClassSchema = new Schema({
    userId: { type: Schema.Types.ObjectId, ref: 'Member', required: true },
    classId: { type: Schema.Types.ObjectId, ref: 'Class', required: true }
});

module.exports = mongoose.model('MemberClass', MemberClassSchema);