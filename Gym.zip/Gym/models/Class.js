const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const ClassSchema = new Schema({
    className: { type: String, required: true },
    classDay: { type: String, required: true },
    sessionLength: { type: Number, required: true },
    price: { type: Number, required: true },
    currentNumberMembers: { type: Number, required: true }
});

module.exports = mongoose.model('Class', ClassSchema);